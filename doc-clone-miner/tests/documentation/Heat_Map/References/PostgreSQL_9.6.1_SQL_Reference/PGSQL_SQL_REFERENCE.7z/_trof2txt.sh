#!/bin/sh

find . -name '*.7' -exec  echo groff -t -e -mandoc -Tascii {} \| col -bx \>\>_all.txt \;
