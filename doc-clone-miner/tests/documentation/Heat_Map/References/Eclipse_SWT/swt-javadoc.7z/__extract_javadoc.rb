#!/usr/bin/env ruby

jdre = /\/\*{2,}(.*?)\n \*+\//m

src = nil

File::open(ARGV[0], 'r:UTF-8') do |f|
  src = f.read
end

jdcs = src.scan(jdre).map do |s|
  s[0].gsub(/\n[ \*]+/, "\n").strip
end

print "====== #{ARGV[0]} ======\n"
print jdcs.join("\n------------\n")
